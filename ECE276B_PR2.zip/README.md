# ECE276B SP21 proj2 Programming Assignment
In this project, I implemented the A* alg by myself, and used the RRTStar class from python motion planning library

The all the main contents are in starter_code file:

## main.py
This is the main file to do the real tests, we can change the algorithm at about line 91

## collsion_check.py
This will provide a class called "collsion_check", which can help us to check if there is any collision between a line and any block in environment

## wAStar.py
This will provide a class to search the path which is based on weighted A* algorithm.

## RRTS.py
This will provide a class to search the path which is based on RRT* algorithm. The class seals the RRTStar class from python motion planning library.

## parameters.py

The file gives all necessary system parameters, and the control input and cost in A* algorithm.