def linear_equation(x1,x2,y1,y2):
    """
        return a,b, where y = ax+b
    """
    if x1 == x2:
        return float("inf"),float("inf")
    a = (y1-y2)/(x1-x2)
    b = y1-a*x1
    return a,b

def hashindex(index):
    # res = 0
    # try:
    #     res = index[0]+index[1]*10000+index[2]*100000000
    # except:
    #     print("error index is:" + str(index))
    #     assert  1== 2
    res = index[0] + index[1] * 10000 + index[2] * 100000000
    return res

def update_list(open):
    # print(open)
    open.sort()
    # try:
    #     open.sort()
    # except:
    #     print(open)
    #     assert 1==2
    nopen_buff = {}
    for i in range(len(open)):
        nopen_buff[hashindex(open[i][1:])] = i
    return  nopen_buff


if __name__ == "__main__":
    open_buff = {}
    open = [[1.0, 36, 36, 32]]
    open_buff = update_list(open)

    print(open)
    print(open_buff)
